<?php return array (
  'failed' => 'Queste credenziali non corrispondono ai nostri registri.',
  'throttle' => 'Troppi tentativi di accesso. Riprovare tra :seconds secondi.',
) ?>