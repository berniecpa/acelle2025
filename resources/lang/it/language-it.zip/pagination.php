<?php return array (
  'next' => 'Successiva &raquo;',
  'previous' => '&laquo; Precedente',
) ?>